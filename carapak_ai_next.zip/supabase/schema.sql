-- Enable extensions
create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

-- categories
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null
);

-- prompts
create table if not exists prompts (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  prompt_text text not null,
  model_targets text[] default '{}',
  category_id uuid references categories(id),
  tags text[] default '{}',
  author text default 'Carapak.AI',
  example_images text[] default '{}',
  likes int default 0,
  copy_count int default 0,
  is_published boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- submissions
create table if not exists submissions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  prompt_text text not null,
  category_slug text,
  tags text[] default '{}',
  email text,
  example_images text[] default '{}',
  status text default 'pending',
  created_at timestamptz default now()
);

-- view for public read
create or replace view prompts_public_view as
select p.id, p.slug, p.title, p.prompt_text, p.model_targets, p.tags,
       p.likes, p.copy_count, p.created_at,
       c.name as category_name
from prompts p
left join categories c on c.id = p.category_id
where p.is_published = true;

-- RLS (simplified)
alter table prompts enable row level security;
alter table submissions enable row level security;

-- Policies
drop policy if exists "prompts_read_public" on prompts;
create policy "prompts_read_public" on prompts for select using (is_published = true);

drop policy if exists "submissions_insert_public" on submissions;
create policy "submissions_insert_public" on submissions for insert with check (true);

drop policy if exists "submissions_admin_all" on submissions;
create policy "submissions_admin_all" on submissions for all using (true);

-- helper RPCs
create or replace function inc_copy(pid uuid) returns void as $$
begin
  update prompts set copy_count = copy_count + 1 where id = pid;
end; $$ language plpgsql security definer;

create or replace function inc_like(pid uuid) returns void as $$
begin
  update prompts set likes = likes + 1 where id = pid;
end; $$ language plpgsql security definer;

-- seed sample
insert into categories (slug, name) values 
  ('portrait','Portrait'), ('product','Product'), ('writing','Writing')
on conflict (slug) do nothing;

insert into prompts (slug,title,prompt_text,model_targets,category_id,tags,is_published,copy_count,likes)
select 'streetwear-portrait','Streetwear Portrait — Moody Neon',
'Create a high-contrast cyberpunk streetwear portrait in a rainy alley, neon reflections on wet asphalt. Frame as 3/4 bust, 50mm lens, shallow depth of field (f/1.8), sharp facial features, subtle skin texture.',
array['ChatGPT Vision','Gemini'], c.id, array['street','neon','cinematic'], true, 71, 23
from categories c where c.slug='portrait'
on conflict (slug) do nothing;

insert into prompts (slug,title,prompt_text,model_targets,category_id,tags,is_published,copy_count,likes)
select 'coffee-hero-shot','Product — Coffee Cup Hero Shot',
'Render a hero shot of a ceramic coffee cup with latte art, on a walnut table. Use a soft window light from the right.',
array['ChatGPT','Stable Diffusion'], c.id, array['coffee','studio','ecommerce'], true, 40, 11
from categories c where c.slug='product'
on conflict (slug) do nothing;

insert into prompts (slug,title,prompt_text,model_targets,category_id,tags,is_published,copy_count,likes)
select 'altseason-carousel','Social — Carousel Explainer (Altseason)',
'Write a 7-slide Instagram carousel explaining altseason in crypto for beginners. Style: friendly Indonesian.',
array['ChatGPT'], c.id, array['instagram','education','crypto'], true, 120, 45
from categories c where c.slug='writing'
on conflict (slug) do nothing;
