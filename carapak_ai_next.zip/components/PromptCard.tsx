import { FC } from 'react'

export interface Prompt {
  id: string
  slug: string
  title: string
  prompt_text: string
  model_targets: string[] | null
  category_name: string | null
  tags: string[] | null
  copy_count: number | null
  likes: number | null
  created_at: string
}

const PromptCard: FC<{ p: Prompt }> = ({ p }) => {
  const copy = async () => {
    await navigator.clipboard.writeText(p.prompt_text)
    fetch('/api/track-copy', { method: 'POST', body: JSON.stringify({ id: p.id }) })
    alert('Prompt tersalin!')
  }
  const share = async () => {
    const url = location.origin + '/p/' + p.slug
    if (navigator.share) await navigator.share({ title: p.title, url })
    else { await navigator.clipboard.writeText(url); alert('Link disalin.') }
  }
  return (
    <article className="card hover:shadow-sm transition">
      <h3 className="font-semibold text-lg leading-tight">{p.title}</h3>
      <div className="mt-2 flex flex-wrap gap-2">
        {(p.tags ?? []).slice(0,3).map(t => (
          <span key={t} className="text-xs px-2 py-1 rounded-full bg-zinc-100 dark:bg-zinc-800">#{t}</span>
        ))}
      </div>
      <p className="mt-3 text-sm text-zinc-600 dark:text-zinc-400 line-clamp-4">{p.prompt_text}</p>
      <div className="mt-4 flex gap-2">
        <button className="btn" onClick={copy}>Copy</button>
        <button className="btn" onClick={share}>Share</button>
      </div>
      <div className="mt-3 text-xs text-zinc-500">{(p.model_targets ?? []).join(', ')} · {p.category_name ?? 'Uncategorized'}</div>
    </article>
  )
}

export default PromptCard
