'use client'
import { useState } from 'react'

export default function SubmitPage(){
  const [loading, setLoading] = useState(false)
  const onSubmit = async (e: any) => {
    e.preventDefault()
    setLoading(true)
    const form = new FormData(e.target)
    const payload = {
      title: form.get('title'),
      prompt_text: form.get('prompt'),
      category_slug: form.get('category'),
      tags: String(form.get('tags')||'').split(',').map(s=>s.trim()).filter(Boolean)
    }
    const res = await fetch('/api/submit', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    setLoading(false)
    if (res.ok) alert('Terima kasih! Prompt masuk antrian (pending).')
    else alert('Gagal: ' + await res.text())
    ;(e.target as HTMLFormElement).reset()
  }
  return (
    <main className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold">Kirim Prompt</h1>
      <p className="text-sm text-zinc-600 dark:text-zinc-400">Akan direview admin sebelum dipublikasikan.</p>
      <form onSubmit={onSubmit} className="mt-6 grid gap-3">
        <label className="grid gap-1">Judul<input name="title" className="border rounded-lg p-2" required/></label>
        <label className="grid gap-1">Prompt<textarea name="prompt" className="border rounded-lg p-2" rows={8} required/></label>
        <label className="grid gap-1">Kategori (slug)<input name="category" className="border rounded-lg p-2"/></label>
        <label className="grid gap-1">Tag (pisahkan koma)<input name="tags" className="border rounded-lg p-2"/></label>
        <button disabled={loading} className="btn-primary">{loading?'Mengirim...':'Kirim'}</button>
      </form>
    </main>
  )
}
