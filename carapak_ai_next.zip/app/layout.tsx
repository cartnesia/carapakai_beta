import './globals.css'
import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Carapak.AI — Prompt Library',
  description: 'Perpustakaan prompt Indonesia: copy, cari, dan pakai prompt siap pakai.',
  icons: { icon: '/favicon.svg' }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body>
        <header className="sticky top-0 z-40 backdrop-blur bg-white/70 dark:bg-zinc-950/70 border-b border-zinc-200/60 dark:border-zinc-800">
          <div className="container py-3 flex items-center gap-3">
            <img src="/favicon.svg" alt="Carapak.AI" className="w-8 h-8"/>
            <Link href="/" className="text-xl font-bold tracking-tight">Carapak.<span className="text-indigo-600">AI</span></Link>
            <nav className="ml-auto flex items-center gap-2">
              <Link className="btn" href="/submit">Kirim Prompt</Link>
              <a className="btn-primary" href="https://instagram.com/Carapak.AI" target="_blank">Ikuti IG</a>
            </nav>
          </div>
        </header>
        <main className="container py-8">{children}</main>
        <footer className="mt-20 border-t border-zinc-200 dark:border-zinc-800">
          <div className="container py-8 text-sm text-zinc-500 flex flex-wrap items-center justify-between gap-3">
            <p>© {new Date().getFullYear()} Carapak.AI</p>
            <div className="flex gap-3">
              <Link href="/terms">Terms</Link>
              <Link href="/privacy">Privacy</Link>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}
