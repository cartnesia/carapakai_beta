import { supabaseServer } from '@/lib/supabaseServer'
import { notFound } from 'next/navigation'

export default async function PromptDetail({ params }: { params: { slug: string } }) {
  const sb = supabaseServer()
  const { data, error } = await sb
    .from('prompts_public_view')
    .select('*')
    .eq('slug', params.slug)
    .single()
  if (error || !data) return notFound()

  return (
    <article className="prose prose-zinc dark:prose-invert">
      <h1>{data.title}</h1>
      <p><strong>Kategori:</strong> {data.category_name ?? 'Uncategorized'}</p>
      <div className="not-prose card">
        <pre className="whitespace-pre-wrap">{data.prompt_text}</pre>
      </div>
      <p>Tag: {(data.tags||[]).map((t:string)=>'#'+t).join(' ')}</p>
    </article>
  )
}
