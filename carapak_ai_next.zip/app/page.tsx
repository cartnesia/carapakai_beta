import PromptCard, { Prompt } from '@/components/PromptCard'
import { supabaseServer } from '@/lib/supabaseServer'
import Link from 'next/link'

async function fetchPrompts(): Promise<Prompt[]> {
  const sb = supabaseServer()
  const { data, error } = await sb
    .from('prompts_public_view')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(60)
  if (error) throw new Error(error.message)
  return data as unknown as Prompt[]
}

export default async function Home() {
  const prompts = await fetchPrompts()
  const tags = Array.from(new Set(prompts.flatMap(p => p.tags ?? []))).slice(0, 24).sort()
  const categories = Array.from(new Set(prompts.map(p => p.category_name).filter(Boolean))) as string[]

  return (
    <>
      <section className="flex flex-col md:flex-row md:items-end gap-3 md:gap-4">
        <div className="grow">
          <label className="block text-sm font-medium mb-1">Cari prompt</label>
          <input placeholder="Ketik judul, isi prompt, atau tag..."
                 className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-4 py-2 outline-none"
                 data-search />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Kategori</label>
          <select className="rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2" data-category>
            <option value="">Semua</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Urutkan</label>
          <select className="rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2" data-sort>
            <option value="newest">Terbaru</option>
            <option value="popular">Terpopuler</option>
            <option value="az">A → Z</option>
          </select>
        </div>
      </section>

      <section className="mt-4 flex flex-wrap gap-2" id="tagRow">
        {tags.map(t => (
          <button key={t} className="px-3 py-1 rounded-full border border-zinc-300 dark:border-zinc-700 text-sm" data-tag={t}>#{t}</button>
        ))}
      </section>

      <section className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4" id="grid">
        {prompts.map(p => (
          <Link key={p.id} href={`/p/${p.slug}`} className="contents">
            <PromptCard p={p}/>
          </Link>
        ))}
      </section>

      <script dangerouslySetInnerHTML={{__html: `
        (function(){
          const grid = document.getElementById('grid');
          const search = document.querySelector('[data-search]');
          const category = document.querySelector('[data-category]');
          const sort = document.querySelector('[data-sort]');
          const tagRow = document.getElementById('tagRow');
          const items = Array.from(grid.children);
          const data = items.map(card=>{
            return {
              el: card,
              title: card.querySelector('h3').textContent.toLowerCase(),
              text: card.querySelector('p').textContent.toLowerCase(),
              tags: Array.from(card.querySelectorAll('.rounded-full')).map(e=>e.textContent.replace('#','').toLowerCase()),
              category: card.querySelector('.text-xs').textContent.split('·').slice(-1)[0].trim().toLowerCase(),
              copies: 0
            }
          });
          let activeTag = null;

          function apply(){
            const q = (search.value||'').toLowerCase();
            const cat = (category.value||'').toLowerCase();
            const order = sort.value;
            let arr = data.slice();
            if (activeTag) arr = arr.filter(x=>x.tags.includes(activeTag));
            if (cat) arr = arr.filter(x=>x.category===cat);
            if (q) arr = arr.filter(x=>x.title.includes(q)||x.text.includes(q)||x.tags.some(t=>t.includes(q)));
            items.forEach(x=>x.style.display='none');
            arr.forEach(x=>x.el.style.display='contents');
          }

          tagRow.addEventListener('click', (e)=>{
            const b = e.target.closest('button'); if(!b) return;
            const t = b.getAttribute('data-tag').toLowerCase();
            activeTag = (activeTag===t)?null:t;
            Array.from(tagRow.children).forEach(btn=>{
              btn.classList.toggle('bg-indigo-600', btn.getAttribute('data-tag').toLowerCase()===activeTag);
              btn.classList.toggle('text-white', btn.getAttribute('data-tag').toLowerCase()===activeTag);
            });
            apply();
          });
          search.addEventListener('input', apply);
          category.addEventListener('change', apply);
          sort.addEventListener('change', apply);
        })();
      `}} />
    </>
  )
}
