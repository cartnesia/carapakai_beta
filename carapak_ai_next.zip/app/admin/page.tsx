'use client'
import { useEffect, useState } from 'react'

export default function Admin(){
  const [passOk, setPassOk] = useState(false)
  const [subs, setSubs] = useState<any[]>([])

  useEffect(()=>{
    const ok = document.cookie.includes('admin=1')
    setPassOk(ok)
    if (ok) load()
  },[])

  const login = async () => {
    const pwd = prompt('Masukkan ADMIN_PASSWORD:')
    if (!pwd) return
    const res = await fetch('/api/admin/login', { method:'POST', body: pwd })
    if (res.ok) { document.cookie='admin=1; path=/'; setPassOk(true); load() }
    else alert('Password salah')
  }

  const load = async () => {
    const r = await fetch('/api/admin/list-submissions')
    const j = await r.json(); setSubs(j)
  }

  const approve = async (id:string) => {
    const r = await fetch('/api/admin/approve', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ id }) })
    if (r.ok) { alert('Approved'); load() } else alert('Gagal')
  }

  if (!passOk) return <main className="container py-8"><button className="btn-primary" onClick={login}>Login Admin</button></main>

  return (
    <main className="container py-8">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <h2 className="font-semibold mb-2">Submission Pending</h2>
      <div className="grid gap-3">
        {subs.map(s=>(
          <article key={s.id} className="card">
            <h3 className="font-semibold">{s.title}</h3>
            <pre className="whitespace-pre-wrap text-sm text-zinc-600 dark:text-zinc-300">{s.prompt_text}</pre>
            <div className="mt-2 text-xs text-zinc-500">Tags: {(s.tags||[]).join(', ')}</div>
            <div className="mt-3 flex gap-2">
              <button className="btn-primary" onClick={()=>approve(s.id)}>Approve → Publish</button>
            </div>
          </article>
        ))}
      </div>
    </main>
  )
}
