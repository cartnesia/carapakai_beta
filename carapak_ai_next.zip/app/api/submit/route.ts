import { NextRequest, NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabaseServer'

export async function POST(req: NextRequest){
  const body = await req.json()
  if (!body?.title || !body?.prompt_text) return new NextResponse('Bad Request', { status: 400 })
  const sb = supabaseServer()
  const { error } = await sb.from('submissions').insert({
    title: body.title,
    prompt_text: body.prompt_text,
    category_slug: body.category_slug || null,
    tags: body.tags || []
  })
  if (error) return new NextResponse(error.message, { status: 500 })
  return NextResponse.json({ ok: true })
}
