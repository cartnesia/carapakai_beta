import { NextRequest, NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabaseServer'
import slugify from '../../../utils/slugify'
export async function POST(req: NextRequest){
  const { id } = await req.json()
  if (!id) return new NextResponse('Missing id', { status: 400 })
  const sb = supabaseServer()
  const { data: sub, error } = await sb.from('submissions').select('*').eq('id', id).single()
  if (error || !sub) return new NextResponse('Not found', { status: 404 })
  const slug = slugify(sub.title)
  const { error: e2 } = await sb.from('prompts').insert({
    slug,
    title: sub.title,
    prompt_text: sub.prompt_text,
    tags: sub.tags || [],
    is_published: true
  })
  if (e2) return new NextResponse(e2.message, { status: 500 })
  await sb.from('submissions').update({ status:'approved' }).eq('id', id)
  return NextResponse.json({ ok: true, slug })
}
