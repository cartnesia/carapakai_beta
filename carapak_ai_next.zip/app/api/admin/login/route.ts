import { NextRequest, NextResponse } from 'next/server'
export async function POST(req: NextRequest){
  const pwd = await req.text()
  if (pwd && pwd === process.env.ADMIN_PASSWORD){
    return new NextResponse('ok', { status: 200 })
  }
  return new NextResponse('forbidden', { status: 403 })
}
