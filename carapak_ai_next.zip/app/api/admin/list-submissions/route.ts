import { supabaseServer } from '@/lib/supabaseServer'
import { NextResponse } from 'next/server'

export async function GET(){
  const sb = supabaseServer()
  const { data, error } = await sb.from('submissions').select('*').eq('status','pending').order('created_at', { ascending:false })
  if (error) return new NextResponse(error.message, { status: 500 })
  return NextResponse.json(data)
}
